# Organização de branches e PRs

A atividade original foi planejada para quatro integrantes. Como o grupo possui dois integrantes, usem esta divisão para representar as quatro funcionalidades sem deixar funcionalidades incompletas.

## Integrante 1

### Branch 1
`feature/index-e-detalhes`

Arquivos:
- `index.php`
- `detalhes.php`

### Branch 2
`feature/formularioCadastroEvento`

Arquivo:
- `cadastro.php`

## Integrante 2

### Branch 3
`feature/formularioEdicaoEvento`

Arquivo:
- `edicao.php`

### Branch 4
`feature/formularioRemocaoEvento`

Arquivo:
- `remocao.php`

## Sugestão de commits

Cada feature deve ter pelo menos um commit claro, por exemplo:

```text
feat: implementa listagem e detalhes de eventos
feat: implementa cadastro de eventos
feat: implementa edição de eventos
feat: implementa remoção de eventos
```

## Pull Requests

Abram um PR para cada branch e descrevam:

1. O que foi implementado.
2. Quais arquivos foram alterados.
3. Como testar.
4. Qual issue está sendo atendida.

Exemplo:

```text
## O que foi feito
Implementei a listagem dos eventos e a página de detalhes.

## Como testar
1. Abra index.php.
2. Clique em Detalhes.
3. Teste um ID inexistente.
4. Remova todos os eventos e confira a mensagem de lista vazia.
```

O gerente pode revisar e integrar os PRs na `main`. Para cumprir a regra de revisão, o outro integrante deve revisar os PRs antes da integração.

## Importante

Não inventem quatro pessoas na entrega. Como o grupo possui dois integrantes, identifiquem os dois participantes reais e expliquem no README que as quatro funcionalidades foram divididas entre os dois.
