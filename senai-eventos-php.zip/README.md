# Sistema de Eventos SENAI

Projeto de atividade prática de PHP e Git para cadastro, consulta, edição e remoção de eventos.

## Tecnologias

- PHP
- HTML
- CSS básico
- `$_SESSION`
- Git e GitHub

## Funcionalidades

- Listagem de eventos
- Detalhes de um evento
- Cadastro
- Edição
- Remoção com confirmação
- Validação de campos obrigatórios
- Validação de horário final maior que o inicial
- Tratamento de ID inexistente
- Tratamento de lista vazia
- IDs controlados por `$_SESSION['proximo_id']`

## Como executar

É necessário ter PHP instalado.

No terminal, dentro da pasta do projeto:

```bash
php -S localhost:8000
```

Depois acesse:

```text
http://localhost:8000/index.php
```

O projeto usa sessão, então os testes devem ser feitos no mesmo navegador.

## Estrutura

- `init.php` - inicialização da sessão e eventos iniciais
- `menu.php` - menu de navegação
- `style.css` - estilos básicos
- `index.php` - listagem
- `detalhes.php` - detalhes
- `cadastro.php` - cadastro
- `edicao.php` - edição
- `remocao.php` - remoção

## Fluxo Git sugerido para a atividade

A atividade original prevê quatro integrantes e quatro branches:

- `feature/index-e-detalhes`
- `feature/formularioCadastroEvento`
- `feature/formularioEdicaoEvento`
- `feature/formularioRemocaoEvento`

Como este grupo possui apenas dois integrantes, o projeto está funcionalmente completo, mas a divisão de quatro participantes/PRs precisa ser adaptada no GitHub de acordo com a organização real do grupo.

Sugestão para dois integrantes:

**Integrante 1**
- Listagem e detalhes
- Cadastro

**Integrante 2**
- Edição
- Remoção

Para a entrega, cada integrante deve trabalhar em branches próprias, fazer commits claros, abrir PRs e integrar tudo na `main`.

## Testes finais

1. Abrir a listagem e consultar os dois eventos iniciais.
2. Cadastrar um evento.
3. Conferir o novo evento na listagem e nos detalhes.
4. Editar o evento e conferir que o ID continua igual.
5. Abrir a remoção e cancelar.
6. Abrir novamente e confirmar a remoção.
7. Tentar acessar um ID inexistente, por exemplo `detalhes.php?id=999`.
8. Remover todos os eventos e conferir a mensagem de lista vazia.
9. Cadastrar outro evento depois de uma remoção e verificar que o ID não sobrescreve outro registro.

## Observação sobre a sessão

Os eventos iniciais são criados apenas quando a sessão ainda não possui `$_SESSION['eventos']`. Portanto, alterar os dados iniciais de `init.php` não reinicia automaticamente uma sessão já existente.

Para começar novamente com os eventos iniciais durante os testes, é possível fechar a sessão/navegador ou limpar os dados de sessão conforme o ambiente utilizado.
